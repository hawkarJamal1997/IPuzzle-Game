//
//  ViewController.swift
//  IPuzzle
//
//  Created by Hawkar Jamal Ali on 2020-11-24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

