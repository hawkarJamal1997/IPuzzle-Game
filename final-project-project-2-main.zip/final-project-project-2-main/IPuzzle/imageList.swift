//
//  imageList.swift
//  IPuzzle
//
//  Created by Hawkar Jamal Ali on 2020-11-24.
//

import Foundation

struct Response: Decodable {
    let imageList: [Images]
}
