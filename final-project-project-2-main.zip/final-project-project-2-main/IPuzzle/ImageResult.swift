//
//  ImageResult.swift
//  IPuzzle
//
//  Created by Hawkar Jamal Ali on 2020-11-24.
//

import Foundation

struct ImageResult: Decodable {
    let result: [Images]
}
